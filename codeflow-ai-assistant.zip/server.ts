import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs/promises";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes for the AI Agent
  app.get("/api/files/list", async (req, res) => {
    try {
      const files = await fs.readdir(process.cwd(), { recursive: true });
      res.json({ files: files.filter(f => !f.includes('node_modules') && !f.includes('.git')) });
    } catch (err) {
      res.status(500).json({ error: "Failed to list files" });
    }
  });

  app.get("/api/files/read", async (req, res) => {
    const filePath = req.query.path as string;
    if (!filePath) return res.status(400).json({ error: "Path required" });
    
    // Basic security: prevent directory traversal
    const resolvedPath = path.resolve(process.cwd(), filePath);
    if (!resolvedPath.startsWith(process.cwd())) {
      return res.status(403).json({ error: "Access denied" });
    }

    try {
      const content = await fs.readFile(resolvedPath, 'utf-8');
      res.json({ content });
    } catch (err) {
      res.status(500).json({ error: "Failed to read file" });
    }
  });

  app.post("/api/terminal/exec", async (req, res) => {
    const { command } = req.body;
    let output = "";
    
    if (command === "ls") {
      const files = await fs.readdir(process.cwd());
      output = files.join("\n");
    } else if (command === "pwd") {
      output = process.cwd();
    } else {
      output = `Executed: ${command}\n(Mock output for security in this demo environment)`;
    }
    
    res.json({ output });
  });

  app.post("/api/files/write", async (req, res) => {
    const { path: filePath, content } = req.body;
    if (!filePath || content === undefined) return res.status(400).json({ error: "Path and content required" });
    
    const resolvedPath = path.resolve(process.cwd(), filePath);
    if (!resolvedPath.startsWith(process.cwd())) {
      return res.status(403).json({ error: "Access denied" });
    }

    try {
      await fs.writeFile(resolvedPath, content, 'utf-8');
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to write file" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
