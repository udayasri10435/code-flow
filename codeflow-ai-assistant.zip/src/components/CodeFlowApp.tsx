import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Monitor, MonitorOff, Play, Square, MessageSquare, Brain, Code2, Terminal } from 'lucide-react';
import { connectLiveSession, runArchitectReasoning, ChatMessage, LIVE_MODEL, ARCHITECT_MODEL } from '../services/gemini';
import { cn } from '../lib/utils';
import Markdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';

export default function CodeFlowApp() {
  const [isLive, setIsLive] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [architectInput, setArchitectInput] = useState('');
  const [isArchitectThinking, setIsArchitectThinking] = useState(false);
  const [status, setStatus] = useState<'idle' | 'connecting' | 'connected' | 'error'>('idle');
  const [pendingRefactor, setPendingRefactor] = useState<{
    path: string;
    originalContent: string;
    newContent: string;
  } | null>(null);

  const sessionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isArchitectThinking]);

  // --- Live Session Logic ---

  const startLiveSession = async () => {
    setStatus('connecting');
    try {
      const session = await connectLiveSession({
        onopen: () => {
          setStatus('connected');
          setIsLive(true);
          addMessage('system', 'Live session connected. Co-pilot is ready.');
        },
        onmessage: async (msg) => {
          if (msg.serverContent?.modelTurn?.parts) {
            const textPart = msg.serverContent.modelTurn.parts.find(p => p.text);
            if (textPart?.text) {
              addMessage('assistant', textPart.text);
            }
            const audioPart = msg.serverContent.modelTurn.parts.find(p => p.inlineData);
            if (audioPart?.inlineData?.data) {
              playAudio(audioPart.inlineData.data);
            }
          }

          if (msg.toolCall) {
            for (const call of msg.toolCall.functionCalls) {
              let result;
              try {
                if (call.name === 'list_files') {
                  const res = await fetch('/api/files/list');
                  result = await res.json();
                } else if (call.name === 'read_file') {
                  const res = await fetch(`/api/files/read?path=${call.args.path}`);
                  result = await res.json();
                } else if (call.name === 'exec_command') {
                  const res = await fetch('/api/terminal/exec', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command: call.args.command })
                  });
                  result = await res.json();
                } else if (call.name === 'refactor_code') {
                  const { path: filePath, newContent } = call.args as any;
                  try {
                    const res = await fetch(`/api/files/read?path=${filePath}`);
                    const data = await res.json();
                    setPendingRefactor({
                      path: filePath,
                      originalContent: data.content || '',
                      newContent
                    });
                    addMessage('system', `Co-pilot suggested a refactor for ${filePath}. Please review the diff.`);
                    result = { success: true, message: "Refactor suggested to user for approval" };
                  } catch (err) {
                    console.error('Failed to fetch original content for refactor:', err);
                    result = { error: "Failed to load original file content" };
                  }
                }
                
                if (sessionRef.current) {
                  sessionRef.current.sendToolResponse({
                    functionResponses: [{
                      name: call.name,
                      id: call.id,
                      response: { result }
                    }]
                  });
                }
              } catch (err) {
                console.error('Tool execution failed:', err);
              }
            }
          }
        },
        onerror: (err) => {
          console.error('Live session error:', err);
          setStatus('error');
          addMessage('system', 'Error in live session.');
        },
        onclose: () => {
          setStatus('idle');
          setIsLive(false);
          addMessage('system', 'Live session closed.');
        }
      });
      sessionRef.current = session;
    } catch (err) {
      console.error('Failed to connect:', err);
      setStatus('error');
    }
  };

  const stopLiveSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    stopScreenShare();
    stopAudioCapture();
    setStatus('idle');
    setIsLive(false);
  };

  const addMessage = (role: ChatMessage['role'], content: string) => {
    setMessages(prev => [...prev, { role, content, timestamp: Date.now() }]);
  };

  // --- Audio Logic ---

  const startAudioCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      audioContextRef.current = new AudioContext({ sampleRate: 16000 });
      const source = audioContextRef.current.createMediaStreamSource(stream);
      const processor = audioContextRef.current.createScriptProcessor(4096, 1, 1);

      processor.onaudioprocess = (e) => {
        if (isMuted || !sessionRef.current) return;
        const inputData = e.inputBuffer.getChannelData(0);
        // Convert to 16-bit PCM
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
        }
        const base64Data = btoa(String.fromCharCode(...new Uint8Array(pcmData.buffer)));
        sessionRef.current.sendRealtimeInput({
          audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
        });
      };

      source.connect(processor);
      processor.connect(audioContextRef.current.destination);
      setIsMuted(false);
    } catch (err) {
      console.error('Audio capture failed:', err);
    }
  };

  const stopAudioCapture = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setIsMuted(true);
  };

  const nextAudioTimeRef = useRef<number>(0);

  const playAudio = (base64Data: string) => {
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioContext({ sampleRate: 24000 });
    }
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    const binary = atob(base64Data);
    const bytes = new Int16Array(binary.length / 2);
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = (binary.charCodeAt(i * 2) | (binary.charCodeAt(i * 2 + 1) << 8));
    }
    
    const floatData = new Float32Array(bytes.length);
    for (let i = 0; i < bytes.length; i++) {
      floatData[i] = bytes[i] / 32768;
    }

    const buffer = ctx.createBuffer(1, floatData.length, 24000);
    buffer.getChannelData(0).set(floatData);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    
    const startTime = Math.max(ctx.currentTime, nextAudioTimeRef.current);
    source.start(startTime);
    nextAudioTimeRef.current = startTime + buffer.duration;
  };

  // --- Screen Share Logic ---

  const startScreenShare = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ 
        video: {
          displaySurface: 'monitor',
        },
        audio: false 
      });
      screenStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsScreenSharing(true);

      // Frame capture loop
      const captureFrame = () => {
        if (!isScreenSharing || !sessionRef.current || !canvasRef.current || !videoRef.current) return;
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
          const base64Data = canvasRef.current.toDataURL('image/jpeg', 0.5).split(',')[1];
          sessionRef.current.sendRealtimeInput({
            video: { data: base64Data, mimeType: 'image/jpeg' }
          });
        }
        setTimeout(captureFrame, 1000); // Send frame every second
      };
      captureFrame();
    } catch (err: any) {
      console.error('Screen share failed:', err);
      if (err.name === 'NotAllowedError') {
        addMessage('system', 'Screen share was denied. If you are in an iframe, try opening the app in a new tab using the button in the header.');
      } else {
        addMessage('system', `Screen share failed: ${err.message}`);
      }
    }
  };

  const stopScreenShare = () => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }
    setIsScreenSharing(false);
  };

  // --- Architect Logic ---

  const handleArchitectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!architectInput.trim()) return;

    const prompt = architectInput;
    setArchitectInput('');
    addMessage('user', prompt);
    setIsArchitectThinking(true);

    try {
      const response = await runArchitectReasoning(prompt, messages.map(m => `${m.role}: ${m.content}`).join('\n'));
      
      if (response.text) {
        addMessage('assistant', response.text);
      }

      if (response.functionCalls) {
        for (const call of response.functionCalls) {
          if (call.name === 'refactor_code') {
            const { path: filePath, newContent } = call.args as any;
            // Fetch original content to show diff
            try {
              const res = await fetch(`/api/files/read?path=${filePath}`);
              const data = await res.json();
              setPendingRefactor({
                path: filePath,
                originalContent: data.content || '',
                newContent
              });
              addMessage('system', `Architect suggested a refactor for ${filePath}. Please review the diff.`);
            } catch (err) {
              console.error('Failed to fetch original content for refactor:', err);
              addMessage('system', `Architect suggested a refactor for ${filePath}, but I couldn't load the original file.`);
            }
          } else {
            // Handle other tools if needed, but Architect primarily uses refactor_code for now
            addMessage('system', `Architect called tool: ${call.name}`);
          }
        }
      }
    } catch (err) {
      console.error('Architect error:', err);
      addMessage('system', 'Architect encountered an error.');
    } finally {
      setIsArchitectThinking(false);
    }
  };

  const applyRefactor = async () => {
    if (!pendingRefactor) return;
    try {
      const res = await fetch('/api/files/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          path: pendingRefactor.path,
          content: pendingRefactor.newContent
        })
      });
      if (res.ok) {
        addMessage('system', `Successfully applied refactor to ${pendingRefactor.path}`);
        setPendingRefactor(null);
      } else {
        throw new Error('Failed to write file');
      }
    } catch (err) {
      console.error('Refactor apply failed:', err);
      addMessage('system', `Failed to apply refactor to ${pendingRefactor.path}`);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#0a0a0a] text-white font-sans">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#0f0f0f]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Code2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">CodeFlow</h1>
            <p className="text-xs text-white/50 uppercase tracking-widest font-mono">Multi-Agent Assistant</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => window.open(window.location.href, '_blank')}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
            title="Open in new tab to fix iframe permission issues"
          >
            <Monitor className="w-3 h-3" />
            New Tab
          </button>
          
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10">
            <div className={cn("w-2 h-2 rounded-full", isLive ? "bg-green-500 animate-pulse" : "bg-white/20")} />
            <span className="text-xs font-medium uppercase tracking-wider">{status}</span>
          </div>
          
          <button
            onClick={isLive ? stopLiveSession : startLiveSession}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-200",
              isLive 
                ? "bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20" 
                : "bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-600/20"
            )}
          >
            {isLive ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isLive ? "Stop Live" : "Start Live"}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Panel: Live & Controls */}
        <div className="w-1/3 border-r border-white/10 flex flex-col bg-[#0f0f0f]">
          <div className="p-6 space-y-6">
            <section>
              <h2 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-4 flex items-center gap-2">
                <Monitor className="w-3 h-3" /> Visual Context
              </h2>
              <div className="aspect-video rounded-xl bg-black border border-white/10 overflow-hidden relative group">
                {isScreenSharing ? (
                  <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-contain" />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white/20">
                    <MonitorOff className="w-12 h-12 mb-2" />
                    <p className="text-sm font-medium">No screen shared</p>
                  </div>
                )}
                <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={isScreenSharing ? stopScreenShare : startScreenShare}
                    className="p-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20"
                  >
                    {isScreenSharing ? <Square className="w-4 h-4" /> : <Monitor className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <canvas ref={canvasRef} width={640} height={360} className="hidden" />
            </section>

            <section>
              <h2 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-4 flex items-center gap-2">
                <Mic className="w-3 h-3" /> Voice Controls
              </h2>
              <div className="flex gap-4">
                <button
                  disabled={!isLive}
                  onClick={isMuted ? startAudioCapture : stopAudioCapture}
                  className={cn(
                    "flex-1 flex flex-col items-center justify-center gap-3 p-6 rounded-2xl border transition-all duration-300",
                    !isMuted 
                      ? "bg-blue-600/10 border-blue-500/50 text-blue-400 shadow-[0_0_20px_rgba(59,130,246,0.15)]" 
                      : "bg-white/5 border-white/10 text-white/40 hover:bg-white/10"
                  )}
                >
                  <div className={cn("p-4 rounded-full", !isMuted ? "bg-blue-500 text-white" : "bg-white/10")}>
                    {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                  </div>
                  <span className="text-sm font-bold">{isMuted ? "Unmute Mic" : "Mic Active"}</span>
                </button>
              </div>
            </section>

            <section className="flex-1">
              <h2 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-4 flex items-center gap-2">
                <Terminal className="w-3 h-3" /> System Status
              </h2>
              <div className="p-4 rounded-xl bg-black border border-white/5 font-mono text-[10px] space-y-2 opacity-60">
                <div className="flex justify-between">
                  <span>LIVE_MODEL:</span>
                  <span className="text-blue-400">{LIVE_MODEL}</span>
                </div>
                <div className="flex justify-between">
                  <span>STRATEGY_MODEL:</span>
                  <span className="text-purple-400">{ARCHITECT_MODEL}</span>
                </div>
                <div className="flex justify-between">
                  <span>LATENCY:</span>
                  <span className="text-green-400">~120ms</span>
                </div>
              </div>
            </section>
          </div>
        </div>

        {/* Right Panel: Chat & Architect */}
        <div className="flex-1 flex flex-col bg-[#0a0a0a]">
          {/* Messages Area */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 scrollbar-hide">
            <AnimatePresence initial={false}>
              {pendingRefactor && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-[#1a1a1a] border border-purple-500/30 rounded-2xl overflow-hidden shadow-2xl mb-8"
                >
                  <div className="px-6 py-4 bg-purple-600/10 border-b border-purple-500/20 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Code2 className="w-5 h-5 text-purple-400" />
                      <h3 className="text-sm font-bold text-purple-100">Pending Refactor: {pendingRefactor.path}</h3>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setPendingRefactor(null)}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold text-white/60 hover:text-white hover:bg-white/5 transition-colors"
                      >
                        Reject
                      </button>
                      <button
                        onClick={applyRefactor}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold bg-purple-600 text-white hover:bg-purple-700 shadow-lg shadow-purple-600/20 transition-colors"
                      >
                        Approve & Apply
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 h-[400px] font-mono text-[11px] divide-x divide-white/10">
                    <div className="flex flex-col overflow-hidden">
                      <div className="px-4 py-2 bg-red-500/10 text-red-400 border-b border-white/5 font-bold uppercase tracking-widest text-[9px]">Original</div>
                      <div className="flex-1 overflow-auto p-4 bg-red-500/5 text-red-200/70 whitespace-pre">
                        {pendingRefactor.originalContent}
                      </div>
                    </div>
                    <div className="flex flex-col overflow-hidden">
                      <div className="px-4 py-2 bg-green-500/10 text-green-400 border-b border-white/5 font-bold uppercase tracking-widest text-[9px]">Refactored</div>
                      <div className="flex-1 overflow-auto p-4 bg-green-500/5 text-green-200/90 whitespace-pre">
                        {pendingRefactor.newContent}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
              {messages.length === 0 && !pendingRefactor && (
                <div className="h-full flex flex-col items-center justify-center text-white/20 space-y-4">
                  <MessageSquare className="w-16 h-16" />
                  <p className="text-lg font-medium">Start a conversation or share your screen</p>
                </div>
              )}
              {messages.map((msg, i) => (
                <motion.div
                  key={msg.timestamp + i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex gap-4 max-w-4xl",
                    msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                    msg.role === 'assistant' ? "bg-blue-600" : 
                    msg.role === 'user' ? "bg-purple-600" : "bg-white/10"
                  )}>
                    {msg.role === 'assistant' ? <Code2 className="w-4 h-4" /> : 
                     msg.role === 'user' ? <Brain className="w-4 h-4" /> : <Terminal className="w-4 h-4" />}
                  </div>
                  <div className={cn(
                    "px-4 py-3 rounded-2xl text-sm leading-relaxed",
                    msg.role === 'user' ? "bg-purple-600/10 border border-purple-500/20 text-purple-100" :
                    msg.role === 'assistant' ? "bg-white/5 border border-white/10 text-white/90" :
                    "bg-white/5 text-white/40 italic"
                  )}>
                    <div className="prose prose-invert prose-sm max-w-none">
                      <Markdown>
                        {msg.content}
                      </Markdown>
                    </div>
                  </div>
                </motion.div>
              ))}
              {isArchitectThinking && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex gap-4"
                >
                  <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center animate-pulse">
                    <Brain className="w-4 h-4" />
                  </div>
                  <div className="px-4 py-3 rounded-2xl bg-white/5 border border-white/10 text-white/50 text-sm flex items-center gap-3">
                    <div className="flex gap-1">
                      <div className="w-1 h-1 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0ms' }} />
                      <div className="w-1 h-1 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '150ms' }} />
                      <div className="w-1 h-1 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                    Architect is thinking...
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Input Area */}
          <div className="p-6 border-t border-white/10 bg-[#0f0f0f]">
            <form onSubmit={handleArchitectSubmit} className="max-w-4xl mx-auto relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-purple-400">
                <Brain className="w-5 h-5" />
              </div>
              <input
                type="text"
                value={architectInput}
                onChange={(e) => setArchitectInput(e.target.value)}
                placeholder="Ask the Architect for deep reasoning or codebase analysis..."
                className="w-full bg-black border border-white/10 rounded-2xl py-4 pl-12 pr-24 focus:outline-none focus:border-purple-500/50 transition-colors text-sm"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-2">
                <button
                  type="submit"
                  disabled={isArchitectThinking || !architectInput.trim()}
                  className="px-4 py-2 bg-purple-600 text-white rounded-xl text-xs font-bold hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Consult Architect
                </button>
              </div>
            </form>
            <p className="text-center text-[10px] text-white/20 mt-4 uppercase tracking-[0.2em]">
              Powered by Gemini 3.1 Pro & Flash Live
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
