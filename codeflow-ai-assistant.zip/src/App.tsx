import CodeFlowApp from './components/CodeFlowApp';

export default function App() {
  return <CodeFlowApp />;
}
