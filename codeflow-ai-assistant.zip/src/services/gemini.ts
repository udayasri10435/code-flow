import { GoogleGenAI, Modality, LiveServerMessage, ThinkingLevel, Type } from "@google/genai";

// Initialize the SDK
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const LIVE_MODEL = "gemini-3.1-flash-live-preview";
export const ARCHITECT_MODEL = "gemini-3.1-pro-preview";

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}

const listFilesTool = {
  name: "list_files",
  description: "List all files in the current project directory.",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const readFileTool = {
  name: "read_file",
  description: "Read the content of a specific file.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      path: { type: Type.STRING, description: "The path to the file to read." },
    },
    required: ["path"],
  },
};

const execCommandTool = {
  name: "exec_command",
  description: "Execute a terminal command.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      command: { type: Type.STRING, description: "The command to execute." },
    },
    required: ["command"],
  },
};

const refactorCodeTool = {
  name: "refactor_code",
  description: "Suggest a refactor for a specific file. Provide the file path and the new content.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      path: { type: Type.STRING, description: "The path to the file to refactor." },
      newContent: { type: Type.STRING, description: "The complete new content for the file." },
    },
    required: ["path", "newContent"],
  },
};

export async function runArchitectReasoning(prompt: string, context: string = "") {
  return ai.models.generateContent({
    model: ARCHITECT_MODEL,
    contents: [
      { role: 'user', parts: [{ text: `Context: ${context}\n\nTask: ${prompt}` }] }
    ],
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
      tools: [
        { functionDeclarations: [listFilesTool, readFileTool, execCommandTool, refactorCodeTool] }
      ],
      systemInstruction: "You are the 'Architect' agent. You provide deep architectural reasoning, whole-codebase analysis, and complex task decomposition. Your goal is to provide strategic guidance for software development in Python, Java, and C#. You can suggest code refactors using the 'refactor_code' tool."
    }
  });
}

export function connectLiveSession(callbacks: {
  onopen?: () => void;
  onmessage: (message: LiveServerMessage) => void;
  onerror?: (error: any) => void;
  onclose?: () => void;
}) {
  return ai.live.connect({
    model: LIVE_MODEL,
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
      },
      tools: [
        { functionDeclarations: [listFilesTool, readFileTool, execCommandTool, refactorCodeTool] }
      ],
      systemInstruction: "You are the 'Co-pilot' agent. You are a real-time, interactive coding assistant. You can see the developer's screen and hear their voice. You provide quick, contextual help, explain code, and diagnose errors seen on screen. You are friendly, concise, and technically expert in Python, Java, and C#. You have access to tools to read files, list project structure, and suggest code refactors.",
    },
  });
}
